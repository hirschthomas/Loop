//
//  NewCarbEntryIntent+Loop.swift
//  Loop
//
//  Copyright © 2018 LoopKit Authors. All rights reserved.
//

import Foundation

@available(iOS 12.0, watchOSApplicationExtension 5.0, *)
extension NewCarbEntryIntent: IdentifiableClass { }
