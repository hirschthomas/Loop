//
//  HUDViewTableViewCell.swift
//  Loop
//
//  Copyright © 2017 LoopKit Authors. All rights reserved.
//

import UIKit
import LoopUI

class HUDViewTableViewCell: UITableViewCell {

    @IBOutlet var hudView: HUDView!

}
