//
//  CarbEntryTableViewController.swift
//  Naterade
//
//  Created by Nathan Racklyeft on 3/11/16.
//  Copyright © 2016 Nathan Racklyeft. All rights reserved.
//

import LoopKitUI


extension CarbEntryTableViewController: IdentifiableClass {
}
