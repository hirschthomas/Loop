//
//  LoopUI.h
//  LoopUI
//
//  Created by Bharat Mediratta on 12/11/16.
//  Copyright © 2016 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoopUI.
FOUNDATION_EXPORT double LoopUIVersionNumber;

//! Project version string for LoopUI.
FOUNDATION_EXPORT const unsigned char LoopUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoopUI/PublicHeader.h>


