//
//  TextFieldTableViewCell.swift
//  Loop
//
//  Copyright © 2018 LoopKit Authors. All rights reserved.
//

import LoopKitUI


extension TextFieldTableViewCell: NibLoadable { }
