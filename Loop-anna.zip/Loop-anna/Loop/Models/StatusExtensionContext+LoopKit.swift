//
//  StatusExtensionContext+LoopKit.swift
//  Loop
//
//  Copyright © 2017 LoopKit Authors. All rights reserved.
//

import LoopKit


extension NetBasalContext {
    var tempBasal: DoseEntry? {
        guard rate != 0 else {
            return nil
        }

        return DoseEntry(
            type: .tempBasal,
            startDate: start,
            endDate: end,
            value: rate,
            unit: .unitsPerHour
        )
    }
}
